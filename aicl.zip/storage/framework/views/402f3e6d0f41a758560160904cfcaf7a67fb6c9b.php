<?php $__env->startSection('title',''); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-12 mt-5">
        <div class="row">
            <aside id="column-right" class="col-sm-3 hidden-xs">
                 <?php echo $__env->make('layouts.partials.user-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            </aside>
            <div id="content" class="col-sm-9">
                <h1><?php echo app('translator')->get('messages.Order'); ?></h1>
                <hr/>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <td class="text-left">#</td>
                                <td class="text-left"><?php echo app('translator')->get('messages.Order-number'); ?></td>
                                <td class="text-left"><?php echo app('translator')->get('messages.Order-date'); ?></td>
                                <td class="text-left"><?php echo app('translator')->get('messages.Status'); ?></td>
                                <td class="text-right"><?php echo app('translator')->get('messages.Grand-total'); ?></td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('user.view-order',$item->id)); ?>"> <?php echo e($item->order_number); ?></a>

                                    </td>
                                    <td><?php echo e(date('d M Y',strtotime($item->order_date))); ?></td>
                                    <td><?php echo e($item->order_status); ?></td>
                                    <td class="text-right"><?php echo app('translator')->get('messages.Tk'); ?> <?php echo e(number_format($item->total_amount,2)); ?></td>
                                </tr>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\atherton-ecommerce\resources\views/frontend/customer/order.blade.php ENDPATH**/ ?>