<?php $__env->startSection('title',''); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-12 mt-5">
            <div class="row">
                <aside id="column-right" class="col-sm-3 hidden-xs">
                    <?php echo $__env->make('layouts.partials.user-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
               </aside>
                <div id="content" class="col-sm-9">
                    <h1><?php echo app('translator')->get('messages.Account'); ?></h1>
                    <hr/>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong><?php echo e($message); ?></strong>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('user.update-info')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <fieldset>
                            <legend><?php echo app('translator')->get('messages.Your'); ?> <?php echo app('translator')->get('messages.Information'); ?></legend>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="input-lastname"><?php echo app('translator')->get('messages.Name'); ?> :</label>
                                <div class="col-sm-10">
                                    <input type="text" name="name" value="<?php echo e($user->name); ?>" placeholder="<?php echo app('translator')->get('messages.Name'); ?> :" id="input-lastname" class="form-control" required/>
                                </div>
                            </div>
                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="input-email"><?php echo app('translator')->get('messages.Email'); ?> :</label>
                                <div class="col-sm-10">
                                    <input type="email" name="email" value="<?php echo e($user->email); ?>" placeholder="<?php echo app('translator')->get('messages.Email'); ?> :" id="input-email" class="form-control" required/>
                                </div>
                            </div>
                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="input-phone"><?php echo app('translator')->get('messages.Phone'); ?> :</label>
                                <div class="col-sm-10">
                                    <input type="tel" name="phone" value="<?php echo e($user->phone_number); ?>" placeholder="<?php echo app('translator')->get('messages.Phone'); ?> :" id="input-phone" class="form-control" required/>
                                </div>
                            </div>
                        </fieldset>
                        <div class="buttons clearfix">
                            <div class="">
                                <button type="submit" class="btn btn-primary"> Update </button>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\atherton-ecommerce\resources\views/frontend/customer/edit.blade.php ENDPATH**/ ?>