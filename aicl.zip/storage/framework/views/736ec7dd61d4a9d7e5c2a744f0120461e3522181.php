<?php $__env->startSection('title','Disorder Show'); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <div class="row page-title">
            <div class="col-md-12">
                <nav aria-label="breadcrumb" class="float-right mt-1">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.disorder.index')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page"> Disorder</li>
                    </ol>
                </nav>
                <h4 class="mb-1 mt-0">Details</h4>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title mt-0 mb-1">Details<a class="btn btn-info btn-xs float-right"
                                                                     href="<?php echo e(route('admin.disorder.index')); ?>">Disorder</a>
                        </h4>
                        <hr/>
                        <div class="modal-body">
                            <table class="table table-straped">
                                <tr>
                                    <th>Disorder Name:</th>
                                    <td><?php echo e($disorder[0]->disorder_name); ?></td>
                                </tr>
                                <tr>
                                    <th>Disorder Name (Bangla):</th>
                                    <td><?php echo e($disorder[0]->disorder_name_bn); ?></td>
                                </tr>
                                <tr>
                                    <th>Symptoms :</th>
                                    <td><?php echo e($disorder[0]->symptoms); ?></td>
                                </tr>
                                <tr>
                                    <th>Symptoms (Bangla):</th>
                                    <td><?php echo e($disorder[0]->symptoms_bn); ?></td>
                                </tr>

                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $productData = getProductById($product->product_id);
                                    ?>
                                    <?php $__currentLoopData = $productData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th>Product : <?php echo e($key+1); ?></th>
                                            <td><?php echo e($disproduct->product_name); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->
    </div>
    <!-- container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

    <?php $__env->startPush('page_js'); ?>

    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nahas\PhpstormProjects\AICL\aicl\resources\views/backend/crops/disorderView.blade.php ENDPATH**/ ?>