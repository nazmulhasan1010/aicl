<?php $__env->startSection('title',''); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>
    <style>
        .invoice-head td {
        padding: 0 8px;
        }
        .container {
        padding-top:30px;
        }
        .invoice-body{
        background-color:transparent;
        }
        .invoice-thank{
        margin-top: 60px;
        padding: 5px;
        }
        address{
        margin-top:15px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-12 mt-5">
        <div class="row">
            <aside id="column-right" class="col-sm-3 hidden-xs">
                 <?php echo $__env->make('layouts.partials.user-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            </aside>
            <div  class="col-sm-9" >
                <h1><?php echo app('translator')->get('messages.Order'); ?></h1>
                <hr/>
                    <div class="container" id="printableArea">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="<?php echo e(asset('frontend/assets/images/aicl_.webp')); ?>" class="img-rounded logo">
                                <p><hr/></p>
                            </div>

                            <div class="col-md-6">
                                <address>
                                    <strong><?php echo e($order->user->name); ?></strong><br>
                                    Phone: <?php echo e($order->user->phone_number); ?><br>
                                    Email: <?php echo e($order->user->email); ?><br>
                                    Address: <?php echo e($order->address); ?><br>
                                    <?php echo e($order->upzila->name); ?>,<?php echo e($order->district->name); ?>,<?php echo e($order->division->name); ?>

                                </address>
                            </div>
                            <div class="col-md-6">
                                <table class="invoice-head mt-3 pull-right text-right">
                                    <tbody>
                                        <tr>
                                            <td class="pull-right"><strong>Invoice #</strong></td>
                                            <td><?php echo e($order->order_number); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="pull-right"><strong>Date</strong></td>
                                            <td><?php echo e(date('d-m-Y',strtotime($order->order_date))); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Status:</td>
                                            <td><?php echo e($order->order_status); ?></td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 well invoice-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th><?php echo app('translator')->get('messages.Product-name'); ?></th>
                                            <th class="text-center"><?php echo app('translator')->get('messages.Pack-size'); ?></th>
                                            <th class="text-center"><?php echo app('translator')->get('messages.Quantity'); ?></th>
                                            <th class="text-right"><?php echo app('translator')->get('messages.Price'); ?></th>
                                            <th class="text-right"><?php echo app('translator')->get('messages.Sub-total'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $order->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td><?php echo e($item->product_name); ?></td>
                                                <td class="text-center"><?php echo e($item->pack_size); ?></td>
                                                <td class="text-center"><?php echo e($item->product_qty); ?></td>
                                                <td class="text-right"><?php echo app('translator')->get('messages.Tk'); ?> <?php echo e(number_format($item->product_price,2)); ?></td>
                                                <td class="text-right"><?php echo app('translator')->get('messages.Tk'); ?> <?php echo e(number_format($item->product_price * $item->product_qty,2)); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan="4"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="4">&nbsp;</td>
                                            <td class="text-right"><strong><?php echo app('translator')->get('messages.Grand-total'); ?></strong></td>
                                            <td class="text-right"><strong><?php echo app('translator')->get('messages.Tk'); ?> <?php echo e(number_format($order->total_amount,2)); ?></strong></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                    <input type="button" class="btn btn-info float-right mb-5" onclick="printDiv('printableArea')" value="Print" />
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
    <script>
        function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;

            window.print();

            document.body.innerHTML = originalContents;
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\atherton-ecommerce\resources\views/frontend/customer/order-details.blade.php ENDPATH**/ ?>