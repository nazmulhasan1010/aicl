
<?php $__env->startSection('title','units'); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- SISTER CONCERNS -->
<div class="container">
    <div class="sister_concerns">
      <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
          <h2 class="text-center"><?php echo app('translator')->get('messages.Sister-concern'); ?></h2>
        </div>
      </div>
      <div class="row unit_box" id="pesticides">
        <div class="col-sm-12 col-md-6 col-lg-6">
          <h3><?php echo app('translator')->get('messages.Pesticides'); ?></h3>
          <p><?php echo app('translator')->get('messages.Pesticides-sub-details'); ?> </p>
          <p><?php echo app('translator')->get('messages.Pesticides-sub-p'); ?></p>
          <ul class="ml-5">
              <li> <?php echo app('translator')->get('messages.Pesticides-sub-li-1'); ?></li>
              <li> <?php echo app('translator')->get('messages.Pesticides-sub-li-2'); ?></li>
              <li> <?php echo app('translator')->get('messages.Pesticides-sub-li-3'); ?></li>
              <li> <?php echo app('translator')->get('messages.Pesticides-sub-li-4'); ?></li>
              <li> <?php echo app('translator')->get('messages.Pesticides-sub-li-5'); ?></li>
          </ul>
          <p><?php echo app('translator')->get('messages.Pesticides-sub-last-details'); ?></p>
        </div>
        <div class="col-sm-12 col-md-6 col-lg-6">
          <img src="<?php echo e(asset('frontend/assets/images/pesticides.webp')); ?>" id="pesticide_details_img" alt="pesticides">
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ussdanir/aicl.ussdevs.host/resources/views/frontend/pesticides.blade.php ENDPATH**/ ?>