
<?php $__env->startSection('title','units'); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>
    <style>
        h2 {
            font-family: system-ui;
            text-transform: uppercase;
            text-align: center;
            line-height: 1.25em;
            font-size: 33px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- SISTER CONCERNS -->
<div class="container">
    <div class="sister_concerns">
      <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
          <h2><?php echo app('translator')->get('messages.Sister-concern'); ?></h2>
        </div>
      </div>
      

      <div class="d-flex justify-content-between">
        <div>
            <a href="#pesticides"  class="btn unit animate__animated animate__fadeInLeftBig animate__repeat-1 1"><?php echo app('translator')->get('messages.Pesticides'); ?></a>
            <img class="unit_top_icon animate__animated animate__fadeInLeft animate__repeat-1	1" src="<?php echo e(asset('frontend/assets/images/unit_icon/top_pesticides.svg')); ?>" alt="Pesticides">
          </div>
          <div>
            <a href="#packaging" class="btn unit animate__animated animate__fadeInLeft animate__repeat-1	1"><?php echo app('translator')->get('messages.Packaging'); ?></a>
            <img class="unit_top_icon animate__animated animate__fadeInLeftBig animate__repeat-1	1" src="<?php echo e(asset('frontend/assets/images/unit_icon/top_packagin.svg')); ?>" alt="Packaging">
          </div>
          <div>
            <a href="#seed" class="btn unit animate__animated animate__fadeInLeft animate__repeat-1	1"><?php echo app('translator')->get('messages.Seed'); ?></a>
            <img class="unit_top_icon animate__animated animate__fadeInRightBig animate__repeat-1	1" src="<?php echo e(asset('frontend/assets/images/unit_icon/top_seed.svg')); ?>" alt="Seed" >
          </div>
          <div>
            <a href="#consumer" class="btn unit animate__animated animate__fadeInRight animate__repeat-1	1"><?php echo app('translator')->get('messages.Consumer'); ?></a>
            <img class="unit_top_icon animate__animated animate__fadeInRightBig animate__repeat-1	1" src="<?php echo e(asset('frontend/assets/images/unit_icon/top_consumer.svg')); ?>" alt="Consumer" >
          </div>
          <div>
            <a href="#construction" class="btn unit animate__animated animate__fadeInRightBig animate__repeat-1	1"><?php echo app('translator')->get('messages.Construction'); ?></a>
            <img class="unit_top_icon animate__animated animate__fadeInRight animate__repeat-1	1" src="<?php echo e(asset('frontend/assets/images/unit_icon/top_construction.webp')); ?>" alt="" srcset="">
          </div>
      </div>
      <div class="row unit_box" id="pesticides">
        <div class="col-sm-12 col-md-6 col-lg-6">
          <h3><?php echo app('translator')->get('messages.Pesticides-p'); ?></h3>
          <p><?php echo app('translator')->get('messages.Pesticides-details'); ?></p>
          <div class="row" id="unit_icon_for_mobile">
            <div class="col-md-6">
              <img src="<?php echo e(asset('frontend/assets/images/unit_icon/1.svg')); ?>" class="animate__animated animate__fadeInLeftBig" alt="" >
            </div>
            <div class="col-md-6">
              <img src="<?php echo e(asset('frontend/assets/images/unit_icon/2.svg')); ?>" alt="">
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-6 col-lg-6">
          <img src="<?php echo e(asset('frontend/assets/images/unit/pesticides.webp')); ?>" id="unit_img_for_mobile" alt="pesticides">
          <a class="btn read_more animate__animated animate__fadeInLeftBig" href="<?php echo e(route('pesticides')); ?>" target="_blank"><?php echo app('translator')->get('messages.Clilk-for-more'); ?></a>
        </div>
      </div>
      <div class="row unit_box" id="packaging">
        <div class="col-sm-12 col-md-6 col-lg-6">
          <h3><?php echo app('translator')->get('messages.Packaging-p'); ?> </h3>
          <p><?php echo app('translator')->get('messages.Packaging-details'); ?> </p>
          <div class="row" id="unit_icon_for_mobile">
            <div class="col-md-2" >
              <img src="<?php echo e(asset('frontend/assets/images/unit_icon/3.svg')); ?>" class="animate__animated animate__fadeInRightBig" alt="" >
            </div>
            <div class="col-md-1">
              <img src="<?php echo e(asset('frontend/assets/images/unit_icon/4.svg')); ?>" class="animate__animated animate__fadeInRight" alt="" >
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-6 col-lg-6">
          <img src="<?php echo e(asset('frontend/assets/images/unit/packaging.webp')); ?>" id="unit_img_for_mobile" alt="packaging">
          <a class="btn read_more animate__animated animate__fadeInLeftBig" href="<?php echo e(route('packaging')); ?>" target="_blank"><?php echo app('translator')->get('messages.Clilk-for-more'); ?></a>
        </div>
      </div>
      <div class="row unit_box" id="seed">
        <div class="col-sm-12 col-md-6 col-lg-6">
          <h3><?php echo app('translator')->get('messages.Seed-p'); ?> </h3>
          <p><?php echo app('translator')->get('messages.Seed-details'); ?> </p>
          <div class="row" id="unit_icon_for_mobile">
            <div class="col-md-2">
              <img class="animate__animated animate__fadeInLeftBig" src="<?php echo e(asset('frontend/assets/images/unit_icon/5.svg')); ?>" alt="" >
            </div>
            <div class="col-md-2">
              <img class="animate__animated animate__fadeInLeft" src="<?php echo e(asset('frontend/assets/images/unit_icon/6.svg')); ?>" alt="" >
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-6 col-lg-6">
          <img src="<?php echo e(asset('frontend/assets/images/unit/seed.webp')); ?>" id="unit_img_for_mobile" alt="Seed">
          <a class="btn read_more animate__animated animate__fadeInLeftBig" href="<?php echo e(route('seed')); ?>" target="_blank"><?php echo app('translator')->get('messages.Clilk-for-more'); ?></a>
        </div>
      </div>
      <div class="row unit_box" id="consumer">
        <div class="col-sm-12 col-md-6 col-lg-6">
          <h3><?php echo app('translator')->get('messages.Consumer-p'); ?> </h3>
          <p><?php echo app('translator')->get('messages.Consumer-details'); ?> </p>
          <div class="row" id="unit_icon_for_mobile">
            <div class="col-md-2">
              <img class="animate__animated animate__fadeInLeftBig" src="<?php echo e(asset('frontend/assets/images/unit_icon/7.svg')); ?>" alt="" >
            </div>
            <div class="col-md-1">
              <img class="animate__animated animate__fadeInLeft" src="<?php echo e(asset('frontend/assets/images/unit_icon/8.svg')); ?>" alt="" >
            </div>
            <div class="col-md-1">
              <img class="animate__animated animate__fadeInLeft" src="<?php echo e(asset('frontend/assets/images/unit_icon/9.svg')); ?>" alt="" >
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-6 col-lg-6">
          <img src="<?php echo e(asset('frontend/assets/images/unit/consumer.webp')); ?>" id="unit_img_for_mobile" alt="consumer">
        </div>
      </div>
      <div class="row unit_box" id="construction">
        <div class="col-sm-12 col-md-6 col-lg-6">
          <h3><?php echo app('translator')->get('messages.Construction-p'); ?></h3>
          <p><?php echo app('translator')->get('messages.Construction-details'); ?></p>
        <div class="row">
          <div class="col-md-5" >
            <a href="https://www.canbdhome.ca/" id="unit_btn_for_mobile"  target="_blank" class="btn const_btn animate__animated animate__fadeInLeftBig">canbdhome.ca</a>
          </div>
          <div class="col-md-2" id="unit_icon_for_mobile">
            <img class="animate__animated animate__fadeInLeft" src="<?php echo e(asset('frontend/assets/images/unit_icon/10.svg')); ?>" alt="" >
          </div>
        </div>
        </div>
        <div class="col-sm-12 col-md-6 col-lg-6">
          <img src="<?php echo e(asset('frontend/assets/images/unit/construction.webp')); ?>" id="unit_img_for_mobile" alt="construction">
          <a class="btn read_more animate__animated animate__fadeInLeftBig" href="https://www.canbdhome.ca/" target="_blank"><?php echo app('translator')->get('messages.Clilk-for-more'); ?></a>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ussdanir/aicl.ussdevs.host/resources/views/frontend/units.blade.php ENDPATH**/ ?>