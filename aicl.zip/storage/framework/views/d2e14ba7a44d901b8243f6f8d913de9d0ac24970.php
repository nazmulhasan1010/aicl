
<?php $__env->startSection('title','Order Edit'); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
 <!-- Start Content-->
 <div class="container-fluid">
    <div class="row page-title">
        <div class="col-md-12">
            <nav aria-label="breadcrumb" class="float-right mt-1">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard.index')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Order Edit</li>
                </ol>
            </nav>
            <h4 class="mb-1 mt-0">Order Edit</h4>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title mt-0 mb-1">Order Edit<a class="btn btn-info btn-xs float-right" href="<?php echo e(route('admin.order.index')); ?>">Orders</a></h4>
                    <hr/>
                    <div class="container" id="printableArea">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="<?php echo e(asset('frontend/assets/images/aicl_.webp')); ?>" class="img-rounded logo">
                                <p><hr/></p>
                            </div>

                            <div class="col-md-6">
                                <address>
                                    <strong><?php echo e($order->user->name); ?></strong><br>
                                    Phone: <?php echo e($order->user->phone_number); ?><br>
                                    Email: <?php echo e($order->user->email); ?><br>
                                    Address: <?php echo e($order->address); ?><br>
                                    <?php echo e($order->upzila->name); ?>,<?php echo e($order->district->name); ?>,<?php echo e($order->division->name); ?>

                                </address>
                            </div>
                            <div class="col-md-6 text-right">
                                <strong>Invoice #</strong>: <?php echo e($order->order_number); ?> <br/>
                                <strong>Date</strong> : <?php echo e(date('d-m-Y',strtotime($order->order_date))); ?>

                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 well invoice-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th><?php echo app('translator')->get('messages.Product-name'); ?></th>
                                            <th class="text-center"><?php echo app('translator')->get('messages.Pack-size'); ?></th>
                                            <th class="text-center"><?php echo app('translator')->get('messages.Quantity'); ?></th>
                                            <th class="text-right"><?php echo app('translator')->get('messages.Price'); ?></th>
                                            <th class="text-right"><?php echo app('translator')->get('messages.Sub-total'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $order->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td><?php echo e($item->product_name); ?></td>
                                                <td class="text-center"><?php echo e($item->pack_size); ?></td>
                                                <td class="text-center"><?php echo e($item->product_qty); ?></td>
                                                <td class="text-right"><?php echo app('translator')->get('messages.Tk'); ?> <?php echo e(number_format($item->product_price,2)); ?></td>
                                                <td class="text-right"><?php echo app('translator')->get('messages.Tk'); ?> <?php echo e(number_format($item->product_price * $item->product_qty,2)); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan="4"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="4">&nbsp;</td>
                                            <td class="text-right"><strong><?php echo app('translator')->get('messages.Grand-total'); ?></strong></td>
                                            <td class="text-right"><strong><?php echo app('translator')->get('messages.Tk'); ?> <?php echo e(number_format($order->total_amount,2)); ?></strong></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <form action="<?php echo e(route('admin.order.update',$order->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <div class="row">
                                        <div class="col-md-4"></div>
                                        <div class="col-md-4">
                                            <select name="order_status" id="" class="form-control">
                                                <option value="Approved">Approved</option>
                                                <option value="Delivered">Delivered</option>
                                                <option value="Cancel">Cancel</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <button type="submit" class="btn btn-success">Update Order</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->
</div>
<!-- container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ussdanir/aicl.ussdevs.host/resources/views/backend/order/edit.blade.php ENDPATH**/ ?>