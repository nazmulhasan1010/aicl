
<?php $__env->startSection('title','corporate-structure'); ?>
<?php $__env->startPush('vendor_css'); ?>
    
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>
    
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
 <!-- corporate-structure -->
 <div class="corporate-parallax-window" data-parallax="scroll" data-image-src="<?php echo e(asset('frontend/assets/images/corporate-structure.webp')); ?>">
 </div>
 <div class="container">
   <div class="row">
     <div class="col-sm-12 col-md-12 col-lg-12 corporate-info">
       <p>Committed to Quality</p>
       <h1>EXPERIENCE ATHERTON GROUP</h1>
     </div>
   </div>
   <div class="row">
     <div class="col-sm-1 col-md-1 col-lg-1"></div>
      <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-sm-5 col-md-5 col-lg-5">
        <div class="employee_box">
            <img src="<?php echo e(asset('storage/employee/'.$employee->image)); ?>" alt="<?php echo e($employee->employee_name); ?>">
            <h2><?php echo e($employee->employee_name); ?></h2>
            <h6><?php echo e($employee->designation); ?></h6>
            <p><?php echo e($employee->employee_email); ?></p>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </div>
 </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>
    
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ussdanir/aicl.ussdevs.host/resources/views/frontend/corporate-structure.blade.php ENDPATH**/ ?>