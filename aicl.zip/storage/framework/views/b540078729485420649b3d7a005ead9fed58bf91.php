<?php $__env->startSection('title','Crops Item'); ?>
<?php $__env->startPush('vendor_css'); ?>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/crops/item.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/crops/singleProduct.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/crops/style.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row item-main-row">
            <div class="col-12 ">
                <div class="row products ">
                    <?php $__currentLoopData = $disorder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disorders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product card">
                            <div class="img-product">
                                <img class="product-img" src="<?php echo e(asset('storage/disorder/'.$disorders->image)); ?>"
                                     class="img-fluid" style="width: 95%; height: 50%">
                            </div>
                            <div class="info-div">
                                <label for="check" class="details">
                                    <?php
                                        if (Session::get('locale')==='bn'){
                                               $name = $disorders->disorder_name_bn;
                                               $symptoms = $disorders->symptoms_bn;
                                            }else{
                                              $name = $disorders->disorder_name;
                                               $symptoms = $disorders->symptoms;
                                            }
                                    ?>
                                    <h5><?php echo e($name); ?></h5>
                                  <strong ><u>Symptoms </u>: </strong><span class="Symptoms">  <?php echo e($symptoms); ?></span>
                                </label>
                            </div>

                            <div class="rating d-flex mt-1">
                                <?php
                                    $disProduct = getDisProduct('disId',$disorders->disorder_id);
                                    $productItem = count($disProduct)-1;
                                    $products = getProductById($disProduct[0]->product_id);
                                ?>
                                <span><strong><u>Product</u></strong> :
                                     <?php
                                         if (Session::get('locale')==='bn'){
                                                echo $products[0]->product_name_bn;
                                             }else{
                                               echo $products[0]->product_name;
                                             }
                                     ?>
                                    <?php echo e(' / '.$productItem); ?> more..</span>
                            </div>
                            <button type="button" class="mt-3 btn-danger modalShow"
                                    data-pid="<?php echo e($disorders->disorder_id); ?>" data-session="<?php echo e(Session::get('locale')); ?>">
                                <?php echo app('translator')->get('messages.Details'); ?>
                            </button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="disorderShow" tabindex="-1" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Descriptions</h5>
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                </div>
                <div class="modal-body">
                    <div class="row ">
                        <div class="col prod-img">
                            <img id="modalDisImage" src="" alt="img-loading">
                        </div>
                        <div class="col-12 description ">
                            <h5 id="modalDisName"></h5>
                            <strong>Symptoms : </strong><span id="modalSymptoms"></span><br>
                            <strong>Affect : </strong><span class="mb-1" id="modalAffect"></span>
                            <p>Solution</p>
                            <strong>Product : </strong><span id="modalProduct"></span><br>
                            <strong>Soil/Drip : </strong><span id="modalSoil"></span>
                            <br>
                            <strong>Benefit : </strong><span
                                id="modalBenefit"></span>
                            <div class="detailBTN" id="detailBTN"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>
    <!-- javaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2"
            crossorigin="anonymous"></script>
    
    <script src="<?php echo e(asset('backend/assets/js/axios.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>

    <script>
        $('.modalShow').click(function () {
            let disId = $(this).data('pid');
            let session = $(this).data('session');

            if (disId) {
                axios.post('disorderDisId/' + disId).then(function (response) {
                    let data = response.data;
                    $('#modalDisImage').attr('src', '<?php echo e(asset('storage/disorder')); ?>' + '/' + data[0].image);
                    if (session === 'bn') {
                        $('#modalDisName').html(data[0].disorder_name_bn);
                        $('#modalSymptoms').html(data[0].symptoms_bn);
                        $('#modalAffect').html(data[0].affect_bn);
                        // $('#modalProduct').html( data[0].);
                        $('#modalSoil').html(data[0].soil_drip_bn);
                        $('#modalBenefit').html(data[0].benefit_bn);
                    } else {
                        $('#modalDisName').html(data[0].disorder_name);
                        $('#modalSymptoms').html(data[0].symptoms);
                        $('#modalAffect').html(data[0].affect);
                        // $('#modalProduct').html( data[0].);
                        $('#modalSoil').html(data[0].soil_drip);
                        $('#modalBenefit').html(data[0].benefit);
                    }
                    axios.post('disorderProduct/' + disId).then(function (response) {
                        let products = response.data;
                        var lanName;
                        $.each(products, function (i, item) {
                            if (session === 'bn') {
                                 lanName = products[i].product[0].product_name_bn;
                            } else {
                                 lanName = products[i].product[0].product_name;
                            }
                            $('#modalProduct').html(lanName);
                            $('<a class="btn btn-primary modalProductLink" href="<?php echo e(url('disorder/product')); ?>/'+products[i].product[0].id+'">').html(lanName).appendTo('#detailBTN');
                        });
                    }).catch(function (error) {
                        console.log(error);
                    });
                }).catch(function (error) {
                    console.log(error)
                })
                $('#disorderShow').modal('show');
            }
        });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nahas\PhpstormProjects\AICL\aicl\resources\views/frontend/crops/item.blade.php ENDPATH**/ ?>