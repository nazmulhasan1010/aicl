<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
            <?php echo SEO::generate(); ?>

        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('backend/assets/images/logo.webp')); ?>">
        <!-- plugins -->
        <link href="<?php echo e(asset('backend/assets/libs/flatpickr/flatpickr.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- laravel-toastr css -->
        <link href="<?php echo e(asset('backend/assets/css/toastr.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- sweetalert2 css -->
        <link href="<?php echo e(asset('backend/assets/css/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- App css -->
        <link href="<?php echo e(asset('backend/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('backend/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('backend/assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- Custom css -->
        <link href="<?php echo e(asset('backend/assets/css/custom.css')); ?>" rel="stylesheet" type="text/css" />
        <?php echo $__env->yieldPushContent('vendor_css'); ?>
        <?php echo $__env->yieldPushContent('page_css'); ?>
    </head>
    <body>
        <!-- Begin page -->
        <div id="wrapper">
            <!-- Topbar Start -->
            <?php echo $__env->make('layouts.backend.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end Topbar -->
            <!-- Left Sidebar Start -->
            <?php echo $__env->make('layouts.backend.partials.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end Left Sidebar -->

            <!-- Start Page Content here -->
            <div class="content-page">
                <div class="content">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                <!-- Footer Start -->
                <?php echo $__env->make('layouts.backend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Footer Start -->
            </div>
            <!-- End Page content -->
           
        </div>
        <!-- Vendor js -->
        <script src="<?php echo e(asset('backend/assets/js/vendor.min.js')); ?>"></script>
        <!-- laravel-toastr css -->
        
        <script src="<?php echo e(asset('backend/assets/js/toastr.min.js')); ?>"></script>
        <!-- sweetalert2 css -->
        <script src="<?php echo e(asset('backend/assets/js/sweetalert2.min.js')); ?>"></script>
        <!-- App js -->
        <script src="<?php echo e(asset('backend/assets/js/app.min.js')); ?>"></script>
        <?php echo Toastr::message(); ?>

        <script>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error('<?php echo e($error); ?>','Error',{
                    closeButton:true,
                    progressBar: true,
                });
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            // 
        // Delete Item
        function deleteItem(id) {
            swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                confirmButtonClass: 'btn btn-danger',
                cancelButtonClass: 'btn btn-success',
                buttonsStyling: false,
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    event.preventDefault();
                    document.getElementById('delete-form-'+id).submit();
                } else if (
                    // Read more about handling dismissals
                    result.dismiss === swal.DismissReason.cancel
                ) {
                    swal(
                        'Cancelled',
                        'Your data is safe :)',
                        'error'
                    )
                }
            })
        }
        </script>
        <?php echo $__env->yieldPushContent('vendor_js'); ?>
        <?php echo $__env->yieldPushContent('page_js'); ?>
     </body>
 </html><?php /**PATH G:\laragon\www\atherton-ecommerce\resources\views/layouts/backend/app.blade.php ENDPATH**/ ?>