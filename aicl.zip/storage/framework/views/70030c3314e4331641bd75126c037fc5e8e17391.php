<div class="list-group">
    <a href="<?php echo e(route('user.dashboard')); ?>" class="list-group-item <?php echo e(Request::is('user/dashboard') ? 'active' : ''); ?>"><?php echo app('translator')->get('messages.My-account'); ?></a>
    <a href="<?php echo e(route('user.edit')); ?>" class="list-group-item <?php echo e(Request::is('user/edit-profile') ? 'active' : ''); ?>"><?php echo app('translator')->get('messages.Account-change'); ?></a>
    <a href="<?php echo e(route('user.password')); ?>" class="list-group-item <?php echo e(Request::is('user/password') ? 'active' : ''); ?>"><?php echo app('translator')->get('messages.Password'); ?></a>
    <a href="<?php echo e(route('user.address')); ?>" class="list-group-item <?php echo e(Request::is('user/address') ? 'active' : ''); ?>"><?php echo app('translator')->get('messages.Address'); ?></a>
    <a href="<?php echo e(route('user.order')); ?>" class="list-group-item <?php echo e(Request::is('user/order') ? 'active' : ''); ?>"><?php echo app('translator')->get('messages.Order'); ?></a>
    <a class="list-group-item" href="<?php echo e(route('logout')); ?>"
        onclick="event.preventDefault();document.getElementById('logout-form').submit();"><?php echo app('translator')->get('messages.Logout'); ?> </a>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
</div>
<?php /**PATH G:\laragon\www\atherton-ecommerce\resources\views/layouts/partials/user-sidebar.blade.php ENDPATH**/ ?>