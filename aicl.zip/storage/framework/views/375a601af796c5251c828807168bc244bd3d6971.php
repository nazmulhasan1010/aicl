<?php $__env->startSection('title','Product Show'); ?>
<?php $__env->startPush('vendor_css'); ?>
    
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>
    
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
 <!-- Start Content-->
 <div class="container-fluid">
    <div class="row page-title">
        <div class="col-md-12">
            <nav aria-label="breadcrumb" class="float-right mt-1">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard.index')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Product Details</li>
                </ol>
            </nav>
            <h4 class="mb-1 mt-0">Product Details</h4>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title mt-0 mb-1">Product Details<a class="btn btn-info btn-xs float-right" href="<?php echo e(route('admin.product.index')); ?>">Products</a></h4>
                    <hr/>
                    <div class="modal-body">
                        <table class="table table-straped">
                            <tr>
                                <th>Product Name:</th>
                                <td><?php echo e($product->product_name); ?></td>
                            </tr>
                            <tr>
                                <th>Product Name (Bangla):</th>
                                <td><?php echo e($product->product_name_bn); ?></td>
                            </tr>
                            <tr>
                                <th>Product Category:</th>
                                <td><?php echo e($product->category->category_name); ?></td>
                            </tr>
                            <tr>
                                <th>Product Details:</th>
                                <td><?php echo $product->product_details; ?></td>
                            </tr>
                            <tr>
                                <th>Product Details (Bangla):</th>
                                <td><?php echo $product->product_details_bn; ?></td>
                            </tr>
                        </table>
                    </div>
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->
</div> 
<!-- container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>
    
<?php $__env->startPush('page_js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nahas\PhpstormProjects\AICL\aicl\resources\views/backend/product/view.blade.php ENDPATH**/ ?>