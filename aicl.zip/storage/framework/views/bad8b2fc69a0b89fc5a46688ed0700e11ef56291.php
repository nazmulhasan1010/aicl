<?php $__env->startSection('title',''); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-12 mt-5">
            <div class="row">
                <aside id="column-right" class="col-sm-3 hidden-xs">
                     <?php echo $__env->make('layouts.partials.user-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
                </aside>
                <div id="content" class="col-sm-9">
                    <h1><?php echo app('translator')->get('messages.Account'); ?></h1>
                    <hr/>
                    <h4><?php echo app('translator')->get('messages.welcome'); ?> <?php echo e(Auth::user()->name); ?></h4>
                    <div class="row">
                        <div class="col-md-4 col-sm-12 mb-3">
                            <div class="dash-count bg-one">
                                <h4 class="pt-3"><?php echo app('translator')->get('messages.Total-order'); ?></h4>
                                <strong><?php echo e($orders->count()); ?></strong>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 mb-3">
                            <div class="dash-count bg-two">
                                <h4 class="pt-3"><?php echo app('translator')->get('messages.Cancel-order'); ?></h4>

                                <strong><?php echo e($cancel_orders->count()); ?></strong>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 mb-3">
                            <div class="dash-count bg-three">
                                <h4 class="pt-3"><?php echo app('translator')->get('messages.Pending-order'); ?></h4>

                                <strong><?php echo e($pending_orders->count()); ?></strong>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <h4 class="mt-3">Latest 5 Orders</h4>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <td class="text-left">#</td>
                                        <td class="text-left"><?php echo app('translator')->get('messages.Order-number'); ?></td>
                                        <td class="text-left"><?php echo app('translator')->get('messages.Order-date'); ?></td>
                                        <td class="text-left"><?php echo app('translator')->get('messages.Status'); ?></td>
                                        <td class="text-right"><?php echo app('translator')->get('messages.Grand-total'); ?></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $orders->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key+1); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('user.view-order',$item->id)); ?>"> <?php echo e($item->order_number); ?></a>

                                            </td>
                                            <td><?php echo e(date('d M Y',strtotime($item->order_date))); ?></td>
                                            <td><?php echo e($item->order_status); ?></td>
                                            <td class="text-right"><?php echo app('translator')->get('messages.Tk'); ?> <?php echo e(number_format($item->total_amount,2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\atherton-ecommerce\resources\views/frontend/customer/dashboard.blade.php ENDPATH**/ ?>