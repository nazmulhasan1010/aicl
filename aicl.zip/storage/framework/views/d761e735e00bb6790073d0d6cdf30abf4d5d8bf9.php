
<?php $__env->startSection('title','careers'); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="career">
    <div class="career-parallax-window" data-parallax="scroll" data-image-src="<?php echo e(asset('frontend/assets/images/careers_bg.webp')); ?>"></div>
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 corporate-info">
          <p><?php echo app('translator')->get('messages.Career-p'); ?> </p>
          <h1><?php echo app('translator')->get('messages.Career-title'); ?> </h1>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-12 col-md-10 col-lg-10 offset-1">
          <h2><?php echo app('translator')->get('messages.Career-open'); ?> </h2>
          <p><?php echo app('translator')->get('messages.For-more-information'); ?>  hr@aicl-bd.com</p>
          <?php $__currentLoopData = $careers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="job_post_1" <?php if($item->deadline > date('Y-m-d')): ?> style="display: block" <?php else: ?> style="display: none" <?php endif; ?>>
            <h2><?php echo e($item->title); ?> - (<?php echo e($item->total_vacancy); ?>)</h2>
            <h4>Deadline : <?php echo e($item->deadline); ?></h4>
            <p>Position Available <span style="margin-left: 80px;"><a href="#application_form" class="btn btn-success">Apply Now</a></span></p>
            <div class="details">
              <?php echo $item->description; ?>

            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <div class="application_form" id="application_form">
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
            </div>
        <?php endif; ?>
        <div class="col-sm-12 col-md-8 col-lg-8 offset-md-2">
          <img src="<?php echo e(asset('frontend/assets/images/career.webp')); ?>" id="career_img" alt="career" class="img-fluid">
          <form action="<?php echo e(route('apply-now')); ?>" method="POST" class="carrer_form" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="fname"><?php echo app('translator')->get('messages.First-name'); ?> <span style="color:red">*</span></label>
              <input type="text" class="form-control" placeholder="<?php echo app('translator')->get('messages.First-name'); ?>" name="fname" id="fname">
            </div>
            <div class="form-group">
              <label for="lname"><?php echo app('translator')->get('messages.Last-name'); ?></label>
              <input type="text" class="form-control" placeholder="<?php echo app('translator')->get('messages.Last-name'); ?>" name="lname" id="lname" >
            </div>
            <div class="form-group">
              <label for="email"><?php echo app('translator')->get('messages.Email'); ?><span style="color:red"> *</span></label>
              <input type="email" class="form-control" placeholder="<?php echo app('translator')->get('messages.Email'); ?>" name="email" id="email" required>
            </div>
            <div class="form-group">
              <label for="phone"><?php echo app('translator')->get('messages.Phone'); ?><span style="color:red"> *</span></label>
              <input type="text" class="form-control" placeholder="<?php echo app('translator')->get('messages.Phone'); ?>" name="phone" id="phone" required>
            </div>
            <div class="form-group">
              <label for="position"><?php echo app('translator')->get('messages.Position'); ?>  <span style="color:red"> *</span></label>
              <select name="position" id="position" class="form-control" required>
                <option selected disabled><?php echo app('translator')->get('messages.Position-you'); ?></option>
                <?php $__currentLoopData = $careers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group">
              <label for="address"><?php echo app('translator')->get('messages.Address'); ?> <span style="color:red"> *</span></label>
              <textarea name="address" id="address" class="form-control" cols="30" rows="4"></textarea>
            </div>
            <div class="form-group">
              <label for="cv">CV <span style="color:red">*</span> <small><?php echo app('translator')->get('messages.CV-must'); ?> </small></label>
              <input type="file" class="form-control" placeholder="CV"  name="cv" id="cv" required>
            </div>
            <div class="form-group">
              <button class="btn btn-success">Submit</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ussdanir/aicl.ussdevs.host/resources/views/frontend/careers.blade.php ENDPATH**/ ?>