<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo SEO::generate(); ?>

    <!-- Bangla Font -->
    
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('backend/assets/images/logo.webp')); ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/bootstrap.min.css')); ?>">
    <!-- FontAwsome CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/font-awesome.css')); ?> ">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noticia+Text:ital,wght@0,400;0,700;1,700&display=swap"
          rel="stylesheet">
    <script src="<?php echo e(asset('frontend/assets/js/bundle.js')); ?>"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
    />
    <!-- responsive style -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/responsive.css')); ?>">
    <!-- laravel-toastr css -->
    <link href="<?php echo e(asset('backend/assets/css/toastr.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="<?php echo e(asset('frontend/assets/js/parallax.min.js')); ?>"></script>
    <!-- Custom style -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/style.css')); ?>">
    <script src="https://kit.fontawesome.com/2e7d7272e8.js" crossorigin="anonymous"></script>
    <style>
        .nav-hover {
            position: relative;
        }

        .nav-hover .nav-drop-item {
            display: none;
            position: absolute;
            top: 45px;
            background-color: #fff;
            border: 1px solid rgba(51, 51, 51, 0.35);
            border-radius: 5px;
            font-size: .8rem;
        }

        .nav-hover .nav-drop-item .crops-items-modal {
            display: flex;
        }

        .nav-drop-item .crops-items-modal .cropsMain {
            text-transform: capitalize;
            justify-content: center;
            padding: 15px 0;
            height: 170px;
            width: 180px;
        }

        .nav-drop-item .crops-items-modal .cropsMain .cropsCatItem {
            padding: 5px 10px;
        }

        .navbar-nav .nav-item .nav-link,
        #navbarNavAltMarkup .navbar-nav .nav-link {
            font-size: 13px;
            padding: 6px;
        }
    </style>
    <?php echo $__env->yieldPushContent('vendor_css'); ?>
    <?php echo $__env->yieldPushContent('page_css'); ?>
</head>
<body>
<!-- nav bar -->
<?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="top_space">
    <!-- main content -->
    <?php echo $__env->yieldContent('content'); ?>
</div>
<!-- footer -->
<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Optional JavaScript; choose one of the two! -->

<!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->

<script src="<?php echo e(asset('frontend/assets/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- laravel-toastr css -->
<script src="<?php echo e(asset('backend/assets/js/toastr.min.js')); ?>"></script>
<?php echo Toastr::message(); ?>

<script>
    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    toastr.error('<?php echo e($error); ?>', 'Error', {
        closeButton: true,
        progressBar: true,
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    $('#cropsDrop').mouseover(function () {
        $('#cropDropMenu').css('display', 'block')
    })
    $('.nav-drop-item').mouseleave(function () {
        $('.nav-drop-item').css('display', 'none')
    })

    $(document).ready(function () {
        let width = $('.nav-hover .nav-drop-item').width() / 2 - 50;
        $('.nav-hover .nav-drop-item').css('left', '-' + width + 'px')
    })

</script>
<?php echo $__env->yieldPushContent('vendor_js'); ?>
<?php echo $__env->yieldPushContent('page_js'); ?>

</body>
</html>
<?php /**PATH C:\Users\nahas\PhpstormProjects\AICL\aicl\resources\views/layouts/app.blade.php ENDPATH**/ ?>