<?php $__env->startSection('title',''); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-12 mt-5">
        <div class="row">
            <aside id="column-right" class="col-sm-3 hidden-xs">
                 <?php echo $__env->make('layouts.partials.user-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            </aside>
            <div id="content" class="col-sm-9">
                <h1><?php echo app('translator')->get('messages.Address'); ?></h1>
                <hr/>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('user.address-update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="address"><?php echo app('translator')->get('messages.Address'); ?></label>
                                <textarea name="address" id="address" rows="5" class="form-control"><?php echo e($user->address); ?></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('messages.Update'); ?></button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\atherton-ecommerce\resources\views/frontend/customer/address.blade.php ENDPATH**/ ?>