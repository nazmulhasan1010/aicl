<!-- nav bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="<?php echo e(route('home')); ?>"> <img src="<?php echo e(asset('frontend/assets/images/logo.webp')); ?>" alt="logo"/>
     <span style="font-family:noticia text,serif"> ATHERTON <span> GROUP </span> </span>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="btn top_btn" href="<?php echo e(route('order-form')); ?>"> <?php echo app('translator')->get('messages.Order-form'); ?> </a>
        <?php if(\Session::get('locale')== "en"): ?>  <?php else: ?> <?php endif; ?>
        <a href="<?php echo e(url('/setlocale/en')); ?>" class="btn top_btn <?php echo e(\Session::get('locale')== "en" ? 'lang_active' :''); ?>">English <img class="flag_img" src="<?php echo e(asset('frontend/assets/images/CAN.png')); ?>" alt="can flag"/></a>

        <a href="<?php echo e(url('/setlocale/bn')); ?>" class="btn top_btn <?php echo e(\Session::get('locale')== "bn" ? 'lang_active' :''); ?>"> <?php echo app('translator')->get('messages.Bangla'); ?> <img class="flag_img" src="<?php echo e(asset('frontend/assets/images/BGD.png')); ?>" alt="bd flag"/></a>

        <img src="<?php echo e(asset('frontend/assets/images/27_years.webp')); ?>" class="nav_img" alt="27 Years"/>

        <a class="nav-link <?php echo e(Request::is('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>"
            <?php if(\Session::get('locale')== "bn"): ?>
            style="margin-left: 20px;"
            <?php endif; ?>
        > <?php echo app('translator')->get('messages.Home'); ?> <span class="sr-only">(current)</span></a>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo app('translator')->get('messages.About'); ?>
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item <?php echo e(Request::is('company-profile') ? 'active' : ''); ?> " href="<?php echo e(route('profile')); ?>"> <?php echo app('translator')->get('messages.Company'); ?></a>
            <a class="dropdown-item <?php echo e(Request::is('financial-partners') ? 'active' : ''); ?> " href="<?php echo e(route('partners')); ?>"> <?php echo app('translator')->get('messages.Financial'); ?></a>
            <a class="dropdown-item <?php echo e(Request::is('dept-distribution') ? 'active' : ''); ?> " href="<?php echo e(route('distribution')); ?>"> <?php echo app('translator')->get('messages.Distribution'); ?></a>
            <a class="dropdown-item <?php echo e(Request::is('corporate-structure') ? 'active' : ''); ?> " href="<?php echo e(route('employee')); ?>"> <?php echo app('translator')->get('messages.Employee'); ?></a>
            <a class="dropdown-item <?php echo e(Request::is('quality-control') ? 'active' : ''); ?> " href="<?php echo e(route('quality-control')); ?>"><?php echo app('translator')->get('messages.Quality'); ?></a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo app('translator')->get('messages.Product-list'); ?>
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <?php
                $categories = \App\Category::where('status',true)->get();


            ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->first): ?>
                        <?php
                            $first = Session::put('first_category',$category->id);
                        ?>
                    <?php endif; ?>
              <a class="dropdown-item" href="<?php echo e(route('product-by-category',$category->id)); ?>">
                <?php if(\Session::get('locale')== "bn"): ?>
                  <?php echo e($category->category_name_bn); ?>

                <?php else: ?>
                  <?php echo e($category->category_name); ?>

                <?php endif; ?>
              </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a class="dropdown-item" href="#"><?php echo app('translator')->get('messages.Order-form'); ?></a>
          </div>
        </li>
        <a class="nav-link <?php echo e(Request::is('support-functions') ? 'active' : ''); ?>" href="<?php echo e(route('support-functions')); ?>"><?php echo app('translator')->get('messages.Functions'); ?></a>
        <a class="nav-link <?php echo e(Request::is('units') ? 'active' : ''); ?>" href="<?php echo e(route('units')); ?>"><?php echo app('translator')->get('messages.Business'); ?></a>
        <a class="nav-link <?php echo e(Request::is('careers') ? 'active' : ''); ?>" href="<?php echo e(route('careers')); ?>"><?php echo app('translator')->get('messages.Career'); ?></a>
        <a class="nav-link <?php echo e(Request::is('contact-us') ? 'active' : ''); ?>" href="<?php echo e(route('contact-us')); ?>"><?php echo app('translator')->get('messages.Contact'); ?></a>
        <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('user.login')); ?>" class="nav-link "><?php echo app('translator')->get('messages.Login'); ?> </a>
          <?php else: ?>
            <a href="<?php echo e(route('user.dashboard')); ?>" class="nav-link"><?php echo app('translator')->get('messages.My-account'); ?>

            </a>
          <?php endif; ?>
        <a class="nav-link" href="<?php echo e(route('shopping-cart')); ?>" style="font-size: 24px">
            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
        </a>
        <span class="cart-count"><?php echo e(\Cart::getTotalQuantity()); ?></span>
      </div>
    </div>
  </nav>
<?php /**PATH G:\laragon\www\atherton-ecommerce\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>