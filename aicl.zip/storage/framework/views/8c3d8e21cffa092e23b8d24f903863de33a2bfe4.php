<?php $__env->startSection('title','Crops'); ?>
<?php $__env->startPush('vendor_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/crops/item.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/crops/singleProduct.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/crops/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/crops/responsive.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- header section-->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 pt-3" style="height: 40px;">
                <h2 class="text-center" style="margin-bottom:20px !important;">CROPS</h2>
                <hr>
            </div>
        </div>
    </div>

    <!-- menu item section -->

    <div class="container-fluid">
        <div class="row flex-row justify-content-start m-2 mt-5">
            <?php
                $cropsCat = getCropsData('','','all');
            ?>
            <?php $__currentLoopData = $cropsCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-2 col-6 col-sm-4 hoverCircle">
                    <a href="<?php echo e(route('disorder',$categories->id)); ?>">
                        <img src="<?php echo e(asset('storage/cropcat/'.$categories->image)); ?>" alt="" class="img-fluid" ><br>
                        <label>
                            <strong>
                                <?php
                                    if (Session::get('locale')==='bn'){
                                            echo $categories->category_name_bn;
                                        }else{
                                            echo $categories->category_name;
                                        }
                                ?>
                            </strong>
                        </label>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
    <script>
        var acc = document.getElementsByClassName("accordion");
        var i;

        for (i = 0; i < acc.length; i++) {
            acc[i].addEventListener("click", function () {
                this.classList.toggle("active");
                var panel = this.nextElementSibling;
                if (panel.style.maxHeight) {
                    panel.style.maxHeight = null;
                } else {
                    panel.style.maxHeight = panel.scrollHeight + "px";
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nahas\PhpstormProjects\AICL\aicl\resources\views/frontend/crops/categories.blade.php ENDPATH**/ ?>