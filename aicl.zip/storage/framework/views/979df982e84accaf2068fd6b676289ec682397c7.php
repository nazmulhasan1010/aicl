<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo SEO::generate(); ?>

    <!-- Bangla Font -->
    
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('backend/assets/images/logo.webp')); ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/bootstrap.min.css')); ?>">
    <!-- FontAwsome CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/font-awesome.css')); ?> ">
    <!-- Custom style -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/style.css')); ?>">
    <script src="<?php echo e(asset('frontend/assets/js/bundle.js')); ?>"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
  />
    <!-- responsive style -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/responsive.css')); ?>">
    <!-- laravel-toastr css -->
    <link href="<?php echo e(asset('backend/assets/css/toastr.min.css')); ?>" rel="stylesheet" type="text/css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="<?php echo e(asset('frontend/assets/js/parallax.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('vendor_css'); ?>
    <?php echo $__env->yieldPushContent('page_css'); ?>
</head>
<body>
    <!-- nav bar -->
    <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- main content -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- footer -->
    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Optional JavaScript; choose one of the two! -->
    
    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    
    <script src="<?php echo e(asset('frontend/assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- laravel-toastr css -->
    <script src="<?php echo e(asset('backend/assets/js/toastr.min.js')); ?>"> </script>
    <?php echo Toastr::message(); ?>

        <script>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error('<?php echo e($error); ?>','Error',{
                    closeButton:true,
                    progressBar: true,
                });
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </script>
    <?php echo $__env->yieldPushContent('vendor_js'); ?>
    <?php echo $__env->yieldPushContent('page_js'); ?>

</body>
</html>
<?php /**PATH G:\laragon\www\atherton-ecommerce\resources\views/layouts/app.blade.php ENDPATH**/ ?>