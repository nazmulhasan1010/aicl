
<?php $__env->startSection('title',''); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-12">
        <div class="row">
            <div id="content" class="col-sm-6 offset-md-3 mt-5 mb-5">
                <h1><?php echo app('translator')->get('messages.Account'); ?></h1>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong><?php echo e($message); ?></strong>
                        </div>
                    <?php endif; ?>
                <hr/>

                <form action="<?php echo e(route('user-signup')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <fieldset id="account">
                        <legend><?php echo app('translator')->get('messages.Your'); ?> <?php echo app('translator')->get('messages.Information'); ?></legend>
                        <div class="form-group required">
                            <label for="input-name"><?php echo app('translator')->get('messages.Name'); ?>: <span style="color:red">*</span></label>
                            <input type="text" name="name" placeholder="<?php echo app('translator')->get('messages.Name'); ?>" id="input-name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label  for="input-email"><?php echo app('translator')->get('messages.Email'); ?>: <span style="color:red">*</span></label>
                            <input type="email" name="email" placeholder="<?php echo app('translator')->get('messages.Email'); ?>" id="input-email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group required">
                            <label  for="input-phone"><?php echo app('translator')->get('messages.Phone'); ?>: <span style="color:red">*</span></label>
                            <input type="tel" name="phone" placeholder="<?php echo app('translator')->get('messages.Phone'); ?>" id="input-phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('phone')); ?>" required autocomplete="phone" autofocus>

                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group required">
                            <label  for="input-address"><?php echo app('translator')->get('messages.Address'); ?>: <span style="color:red">*</span></label>
                            <input type="text" name="address" placeholder="<?php echo app('translator')->get('messages.Address'); ?>" id="input-address" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('address')); ?>" required autocomplete="address" autofocus/>

                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </fieldset>
                    <fieldset>
                        <legend><?php echo app('translator')->get('messages.Your-password'); ?></legend>
                        <div class="form-group required">
                            <label  for="input-password"><?php echo app('translator')->get('messages.Password'); ?>: <span style="color:red">*</span></label>
                            <input type="password" name="password" placeholder="<?php echo app('translator')->get('messages.Password'); ?>" id="input-password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group required">
                            <label  for="password-confirm"><?php echo app('translator')->get('messages.Confirm-password'); ?>: <span style="color:red">*</span></label>
                            <input id="password-confirm" placeholder="<?php echo app('translator')->get('messages.Confirm-password'); ?>" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                        </div>
                    </fieldset>

                    <div class="buttons">
                        <div class="pull-right">
                            <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('messages.Submit'); ?></button>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ussdanir/aicl.ussdevs.host/resources/views/frontend/customer/register.blade.php ENDPATH**/ ?>