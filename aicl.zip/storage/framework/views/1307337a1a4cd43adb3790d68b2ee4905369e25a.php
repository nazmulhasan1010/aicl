<?php $__env->startSection('title','corporate-structure'); ?>
<?php $__env->startPush('vendor_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/dpt-image.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $start = 0;
         $scroll='';
        $pages = 4;
        $clickPage = 0;
        $employees = getEmployees($start, $pages, 'all');
        $item = count($employees);
        $page = ceil($item/5);
        if (isset($_GET['page'])){
            $clickPage = $_GET['page'];
            $start = ($clickPage-1)*$pages;
            $scroll='ok';
        }
        $employees = getEmployees($start, $pages, 'spe');
    ?>
        <!-- corporate-structure -->
    <div class="corporate-parallax-window" data-parallax="scroll"
         data-image-src="<?php echo e(asset('frontend/assets/images/corporate-structure.webp')); ?>">
    </div>
    <div class="container">
        <div class="row ">
            <div class=" col-md-12 corporate-info">
                <p><?php echo app('translator')->get('messages.Career-p'); ?> </p>
                <h2><?php echo app('translator')->get('messages.Career-title'); ?> </h2>
            </div>
        </div>
        <div class="row justify-content-center">
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-5 col-md-5 col-lg-5">
                    <div class="employee_box">
                        <img src="<?php echo e(asset('storage/employee/'.$employee->image)); ?>" alt="<?php echo e($employee->employee_name); ?>">
                        <h2><?php echo e($employee->employee_name); ?></h2>
                        <h4 style="font-weight: bold; color: rgba(51,51,51,0.50)"><?php echo e($employee->designation); ?></h4>
                        <?php if($employee->degree != null): ?>
                            <h5 style="font-weight: bold;"><?php echo e($employee->degree); ?></h5>
                        <?php endif; ?>
                        <?php if($employee->employee_email != null): ?>
                            <p><?php echo e($employee->employee_email); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if($item>5): ?>
            <nav aria-label="Page navigation example ">
                <ul class="pagination justify-content-center ">
                    <li class="page-item <?php echo e($start===0?'disabled':''); ?>">
                        <a class="page-link" href="?page=<?php echo e($clickPage-1); ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                            <span class="sr-only"></span>
                        </a>
                    </li>
                    <?php for($i= 1; $i <= $page; $i++): ?>
                        <li class="page-item <?php echo e($clickPage == $i?'active-pagi':''); ?>"><a class="page-link"
                                                                                       href="?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?php echo e($start>$item-6?'disabled':''); ?>">
                        <a class="page-link" href="?page=<?php echo e($clickPage+1); ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                            <span class="sr-only"></span>
                        </a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>
        <?php $__env->stopSection(); ?>
        <?php $__env->startPush('vendor_js'); ?>

        <?php $__env->stopPush(); ?>
        <?php $__env->startPush('page_js'); ?>
            <script>
                <?php if( $scroll==='ok'): ?>
                windowScroll();
                <?php endif; ?>
                function windowScroll() {
                    window.scroll({
                        top: 500,
                        behavior: 'smooth'
                    });
                }
            </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nahas\PhpstormProjects\AICL\aicl\resources\views/frontend/corporate-structure.blade.php ENDPATH**/ ?>