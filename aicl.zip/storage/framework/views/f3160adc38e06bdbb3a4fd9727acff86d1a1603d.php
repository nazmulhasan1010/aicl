<?php $__env->startSection('title',''); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-12 mt-5">
        <div class="row">
            <aside id="column-right" class="col-sm-3 hidden-xs">
                <?php echo $__env->make('layouts.partials.user-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
           </aside>
            <div id="content" class="col-sm-9">
                <h1><?php echo app('translator')->get('messages.Account'); ?> <?php echo app('translator')->get('messages.Password'); ?></h1>
                <hr/>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
                <?php if($message = Session::get('warning')): ?>
                <div class="alert alert-warning alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
                <form action="<?php echo e(route('user.update-password')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <fieldset>
                        <div class="form-group required">
                            <label for="old-password"><?php echo app('translator')->get('messages.Old-password'); ?>: <span style="color:red">*</span></label>
                            <input type="password" name="old_password" placeholder=" <?php echo app('translator')->get('messages.Old-password'); ?> :" id="old-password" class="form-control" required/>

                        </div>
                        <div class="form-group required">
                            <label  for="input-password"><?php echo app('translator')->get('messages.Password'); ?>: <span style="color:red">*</span></label>
                            <input type="password" name="password" placeholder="<?php echo app('translator')->get('messages.Password'); ?>" id="input-password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group required">
                            <label  for="password-confirm"><?php echo app('translator')->get('messages.Confirm-password'); ?>: <span style="color:red">*</span></label>
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="<?php echo app('translator')->get('messages.Confirm-password'); ?>" required autocomplete="new-password">
                        </div>
                    </fieldset>
                    <div class="buttons clearfix">
                        <div class="">
                            <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('messages.Update'); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\atherton-ecommerce\resources\views/frontend/customer/password.blade.php ENDPATH**/ ?>