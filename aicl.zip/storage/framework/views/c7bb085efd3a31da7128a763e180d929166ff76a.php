<?php $__env->startSection('title','Product Edit'); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
 <!-- Start Content-->
 <div class="container-fluid">
    <div class="row page-title">
        <div class="col-md-12">
            <nav aria-label="breadcrumb" class="float-right mt-1">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard.index')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Product Edit</li>
                </ol>
            </nav>
            <h4 class="mb-1 mt-0">Product Edit</h4>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title mt-0 mb-1">Product Edit<a class="btn btn-info btn-xs float-right" href="<?php echo e(route('admin.product.index')); ?>">Products</a></h4>
                    <hr/>
                    <div class="modal-body">
                        <form action="<?php echo e(route('admin.product.update',$product->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name">Product Name  <span style="color: red">*</span></label>
                                        <input type="text" id="name" name="name" class="form-control" placeholder="Product Name" value="<?php echo e($product->product_name); ?>" autocomplete="off" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name_bn">Product Name (Bangle) <span style="color: red">*</span></label>
                                        <input type="text" id="name_bn" name="name_bn" class="form-control" placeholder="Product Name (Bangla)" value="<?php echo e($product->product_name_bn); ?>" autocomplete="off" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="category">Category<span style="color: red">*</span></label>
                                    <select name="category" id="category" class="form-control">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $length = (strlen($item->auto_code) - 2);
                                            $widthSpace = ($length * 3);
                                        ?>
                                        <option <?php echo e($product->category_id == $item->id ? 'selected' : ''); ?>  value="<?php echo e($item->id); ?>"><?php echo str_repeat('&nbsp;', $widthSpace) ?><?php echo e($item->category_name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label for="image">Image<span style="color: red">*</span></label>
                                    <div class="form-group">
                                        <input type="file" class="form-control" name="image">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Pack Size</th>
                                            <th>Qty</th>
                                            <th>Price</th>
                                            <th><a href="#" class="addRow">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                            </a></th>
                                        </tr>
                                    </thead>
                                    <tbody id="customtbl">
                                        <?php $__currentLoopData = $varients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $varient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <select name="rows[0][size_id]"  class="form-control">
                                                    <option value="0">-- Select Pack Size--</option>
                                                    <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e($varient->size_id == $size->id ? 'selected' : ''); ?> value="<?php echo e($size->id); ?>"><?php echo e($size->size_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td><input type="text" value="<?php echo e($varient->qty); ?>" name="rows[0][qty]" class="form-control" required=""/></td>
                                            <td><input type="text" value="<?php echo e($varient->price); ?>" name="rows[0][price]" class="form-control" required=""/></td>


                                            <td><button type="button" class="btn btn-danger btn-sm btn-rect" onclick="javascript:remove25(this);">Close</button></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <label for="composition">Product Composition </label>
                                    <textarea name="composition" id="composition" cols="30" rows="3" class="form-control"> <?php echo e($product->composition); ?></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <label for="meta">Product Meta  <span style="color: red">*</span></label>
                                    <textarea name="meta" id="meta" cols="30" rows="5" class="form-control"><?php echo e($product->meta); ?></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <label for="description">Product Description <span style="color: red">*</span></label>
                                    <textarea name="description" id="description" cols="30" rows="10"><?php echo e($product->product_details); ?></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <label for="description_bn">Product Description (Bangla) <span style="color: red">*</span></label>
                                    <textarea name="description_bn" id="description_bn" cols="30" rows="10"><?php echo e($product->product_details_bn); ?></textarea>
                                </div>
                            </div>
                            <div class="form-group mt-3">
                                <button type="submit" class="btn btn-primary waves-effect waves-light mr-1 pull-right">Update</button>
                            </div>
                        </form>
                    </div>
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->
</div>
<!-- container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>
    <!-- summernote init -->
    <script src="<?php echo e(asset('backend/assets/js/summernote-lite.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
    <script>

        // summbernote
        $('#description').summernote({
            tabsize: 2,
            height: 120,
            toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'underline', 'clear']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']],
            ['view', ['fullscreen', 'codeview', 'help']]
            ]
        });
        $('#description_bn').summernote({
            tabsize: 2,
            height: 120,
            toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'underline', 'clear']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']],
            ['view', ['fullscreen', 'codeview', 'help']]
            ]
        });
        $('#productDescription').summernote({
            tabsize: 2,
            height: 120,
            toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'underline', 'clear']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']],
            ['view', ['fullscreen', 'codeview', 'help']]
            ]
        });


    </script>
    <script type="text/javascript">
        var i75 = 0;
        $('.addRow').on('click',function(){
            addRow();
        });
        function addRow()
        {
            i75++;
            var tr='<tr>'+
                '<td>'+'<select name="rows['+i75+'][size_id]" onchange=\'PaymentType(this,'+i75+');\' class="form-control">\n' +
                '<option value="0">-- Select Category--</option>\n'+
                    '<?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>'+
                        '<option value="<?php echo e($size->id); ?>"><?php echo e($size->size_name); ?></option>'+
                    '<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>'+
                '</select>' +
                '</td>'+
                '<td><input type="text" name="rows['+i75+'][qty]" class="form-control" required=""></td>'+
                '<td><input type="text" name="rows['+i75+'][price]" class="form-control" required=""></td>'+
                '<td><button type=\'button\' class=\'btn btn-danger btn-sm btn-rect\' onclick=\'javascript:remove25(this);\'>Close</button></td>'+
                '</tr>';
            $('#customtbl').append(tr);
        };
        function remove25(index){
            //console.log("hello");
            $(index).parent().parent().remove();
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nahas\PhpstormProjects\AICL\aicl\resources\views/backend/product/edit.blade.php ENDPATH**/ ?>