<?php $__env->startSection('title','Products'); ?>
<?php $__env->startPush('vendor_css'); ?>
    <script src="<?php echo e(asset('frontend/assets/js/jquery-2.1.1.min.js')); ?>" type="text/javascript"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Product -->
    <div class="products">
        <?php echo $page_design->design; ?>

        <div id="product-category" class="container">
          <ul class="breadcrumb">
            <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('messages.Home'); ?></a></li>
            <li><a href="#"><?php echo app('translator')->get('messages.Product-list'); ?></a></li>
            <li><a href="#">
                <?php if(Session::get('locale')== "en"): ?>
                <?php echo e($page_design->category_name); ?>

                <?php else: ?>
                <?php echo e($page_design->category_name_bn); ?>

                <?php endif; ?></a></li>
          </ul>
          <div class="row">
            <aside id="column-left" class="col-sm-3 hidden-xs">
              <div class="list-group">
                <a href="#" class="list-group-item active"><?php echo app('translator')->get('messages.Product-list'); ?></a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('product-by-category',$category->id)); ?>" class="list-group-item <?php if($page_design->id ==$category->id): ?>
                        active
                    <?php endif; ?>">-
                        <?php if(Session::get('locale')== "en"): ?>
                        <?php echo e($category->category_name); ?>

                        <?php else: ?>
                        <?php echo e($category->category_name_bn); ?>

                        <?php endif; ?>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </aside>
            <div id="content" class="col-sm-9">
              <div class="row d-flex justify-content-between align-items-center">
                <div class="col-md-2 col-sm-6 ">
                  <div class="btn-group btn-group-sm">

                    <button type="button" id="list-view" class="btn btn-success" data-toggle="tooltip" title=""
                      data-original-title=""><i class="fa fa-th-list"></i></button>
                    <button type="button" id="grid-view" class="btn btn-success active" data-toggle="tooltip" title=""
                      data-original-title=""><i class="fa fa-th"></i></button>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">

                </div>
                <div class="col-md-4 col-xs-6">
                  <div class="form-group">
                    <label for="">Show</label>
                    <select name="" id="" class="form-control">
                      <option value="">স্বাভাবিক</option>
                      <option value="">নাম (A- Z)</option>
                      <option value="">নাম(Z - A)</option>
                    </select>
                  </div>
                </div>
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>Number</label>
                    <select id="input-limit" class="form-control" onchange="location = this.value;">
                      <option value="#" selected="selected">20
                      </option>
                      <option value="#">25</option>
                      <option value="#">50</option>
                      <option value="#">75</option>
                      <option value="#">100</option>
                    </select>
                  </div>
                </div>
              </div>
              <hr/>
              <div class="row">
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <form action="<?php echo e(route('add-to-cart')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="product-thumb">
                                <div class="image">
                                <a href="<?php echo e(route('product-details',[$product->id,$product->slug])); ?>"><img src="<?php echo e(asset('storage/product/'.$product->image)); ?>" alt="<?php echo e($product->product_name_bn); ?>" title="<?php echo e($product->product_name_bn); ?>" class="img-responsive mt-2"> </a>
                                </div>
                                <div>
                                <div class="caption">
                                    <h4>
                                    <a href="<?php echo e(route('product-details',[$product->id,$product->slug])); ?>">
                                        <?php if(Session::get('locale')== "en"): ?>
                                            <?php echo e($product->product_name); ?>

                                        <?php else: ?>
                                            <?php echo e($product->product_name_bn); ?>

                                        <?php endif; ?>

                                    </a>
                                    </h4>
                                    <p>
                                        <?php if(Session::get('locale')== "en"): ?>
                                            <?php echo Str::limit(strip_tags($product->product_details), 100); ?>

                                        <?php else: ?>
                                            <?php echo Str::limit(strip_tags($product->product_details_bn), 100); ?>

                                        <?php endif; ?>
                                    </p>
                                    <?php
                                        $pack_size = \App\PackSize::where('id',$product->variants()->first()->size_id)->first();
                                    ?>
                                    <p></p>
                                    <p class="price"> <?php echo e($pack_size->size_name); ?></p>
                                    <h2><?php echo app('translator')->get('messages.Tk'); ?> <?php echo e(number_format($product->variants()->first()->price,2)); ?></h2>

                                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                    <input type="hidden" name="price" value="<?php echo e($product->variants()->first()->price); ?>">
                                    <input type="hidden" name="size" value="<?php echo e($pack_size->size_name); ?>">
                                    <input type="hidden" name="qty" value="1">
                                </div>
                                <div class="button-group">
                                    <button type="button" onclick="location.href='<?php echo e(route('product-details',[$product->id,$product->slug])); ?>'"><i class="fa fa-bullseye"></i> <?php echo app('translator')->get('messages.Details'); ?></button>
                                    <button type="submit" class="pav-quickview"><i class="fa fa-shopping-cart"></i> <?php echo app('translator')->get('messages.Buy-now'); ?> </button>

                                </div>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
    <script src="<?php echo e(asset('frontend/assets/js/custom.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\atherton-ecommerce\resources\views/frontend/product-by-category.blade.php ENDPATH**/ ?>