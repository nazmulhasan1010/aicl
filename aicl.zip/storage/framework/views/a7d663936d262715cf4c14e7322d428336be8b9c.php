<?php $__env->startSection('title','financial-partners'); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="financial-partners">
    <div class="container partners">
      <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
          <h3><?php echo app('translator')->get('messages.Financial-partners'); ?></h3>
        </div>
        <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-12 col-md-12 col-lg-12 partners_box">
            <img src="<?php echo e(asset('storage/partner/'.$partner->image)); ?>" class="img-fluid" alt="islami_bank">
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nahas\PhpstormProjects\AICL\aicl\resources\views/frontend/financial-partners.blade.php ENDPATH**/ ?>