<?php $__env->startSection('title','Product Details'); ?>
<?php $__env->startPush('vendor_css'); ?>

<?php $__env->startPush('page_css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div id="product-product" class="container mt-5">
    <div class="row">
        <div id="content" class="col-sm-12">
            <div class="row">
                <?php
                    if (Session::get('locale')== "en"){
                        $title = $details->product_name;
                    }
                    else{
                        $title = $details->product_name_bn;
                    }
                ?>
                <div class="col-sm-8">
                    <div class="product_image">
                        <img src="<?php echo e(asset('storage/product/'.$details->image)); ?>" title="<?php echo e($title); ?>" alt="<?php echo e($title); ?>" class="img-thumbnail"/>
                    </div>
                    <h3 class="mt-5"><?php echo app('translator')->get('messages.Description'); ?></h3><hr/>
                    <div class="tab-content">
                        <?php if(Session::get('locale')== "en"): ?>
                            <?php echo $details->product_details; ?>

                        <?php else: ?>
                            <?php echo $details->product_details_bn; ?>

                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-sm-4">
                    <form action="<?php echo e(route('add-to-cart')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <h1><?php echo e($title); ?></h1>
                        <input type="hidden" name="product_id" id="" value="<?php echo e($details->id); ?>">
                        <ul class="list-unstyled">
                            <li><?php echo e($details->composition); ?></li>
                        </ul>
                        <div id="product">
                            <hr />
                            <div class="form-group required">
                                <h5><?php echo app('translator')->get('messages.Quantity'); ?> - <?php echo app('translator')->get('messages.Price'); ?></h5>
                                <div id="input-option254">
                                    <div class="radio">
                                        <label>
                                            <?php $__currentLoopData = $pack_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <input type="radio" name="option" value="<?php echo e($size->id); ?>" required/>
                                            <?php echo e($size->size->size_name); ?>  - <?php echo app('translator')->get('messages.Tk'); ?> <?php echo e(number_format($size->price,2)); ?>

                                                <br/>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="number" min="1" name="qty" id="" class="form-control" value="1">
                                <br />
                                <button type="submit" id="button-cart" data-loading-text="" class="btn btn-primary btn-lg btn-block"><?php echo app('translator')->get('messages.Add-to-cart'); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor_js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
    <script src="<?php echo e(asset('frontend/assets/js/custom.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nahas\PhpstormProjects\AICL\aicl\resources\views/frontend/product-details.blade.php ENDPATH**/ ?>