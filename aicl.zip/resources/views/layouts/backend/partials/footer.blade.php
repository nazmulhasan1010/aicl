<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                {{ date('Y')}} &copy; Etherton. All Rights Reserved. Crafted with <i class='uil uil-heart text-danger font-size-12'></i> by <a href="https://ussit.net/" target="_blank">USS</a>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->