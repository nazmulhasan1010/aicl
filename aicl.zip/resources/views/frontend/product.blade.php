@extends('layouts.app')
@section('title','Product')
@push('vendor_css')
    
@endpush
@push('page_css')
    
@endpush
@section('content')


@endsection
@push('vendor_js')
    
@endpush
@push('page_js')
    
@endpush