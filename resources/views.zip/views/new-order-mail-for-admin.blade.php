<p>{{ $order_number }}</p>
<p>Sending Mail from Laravel.</p>
